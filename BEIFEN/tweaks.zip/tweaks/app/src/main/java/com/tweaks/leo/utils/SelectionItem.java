package com.tweaks.leo.utils;
/*
Created by Roberto Mariani & Anna Berkovitch on 27-Jul-17.

This file is part of 6thGear-RomControl-v2.0

        6thGear-RomControl-v2.0 is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License, or
        (at your option) any later version.

        6thGear-RomControl-v2.0 is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with 6thGear-RomControl-v2.0.  If not, see <http://www.gnu.org/licenses/>.
*/


public class SelectionItem {
    public String entry, value;
    public boolean isSelected;
}
