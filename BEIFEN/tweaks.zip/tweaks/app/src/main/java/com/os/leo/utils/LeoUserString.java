package com.os.leo.utils;


import android.content.Context;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;



import java.io.File;
import java.io.FileInputStream;
import java.util.Date;




public class LeoUserString{
  
    public static void LeoAction( Context context,int defStyle, String appkey) {
        switch (defStyle) {
           

        }
    }
   

}